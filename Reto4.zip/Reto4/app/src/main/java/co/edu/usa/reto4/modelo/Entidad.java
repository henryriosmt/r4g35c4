package co.edu.usa.reto4.modelo;

public class Entidad {

    int imagen;
    //byte[] imagen;
    String titulo;
    String descripcion;

    public Entidad(int imagen, String titulo, String descripcion) {
        this.imagen = imagen;
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    public int getImagen() {
        return imagen;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
